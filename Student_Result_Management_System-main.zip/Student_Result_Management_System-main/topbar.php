<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="css/topbar.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body style="float:top">
    <ul class="navbar, ul-horizontal">
        <li class="li-horizontal brand">
            <a href="index.php"> 
                <b class="name">Resultaholic<span style="color: orange;">.io<span></b>
                <b class="name-1">Resultaholic.io</b>
            </a>
        </li>
        <div class="helpline" style="float:right">
            <li class="li-horizontal">
                <a href="contactus.php"><b class="call">Helpline</b>
                <i style="font-size:20px;margin-top:2px" class="fa"> &#xf095;</i></a>
            </li>
        </div>
    </ul>

</body>
</html>