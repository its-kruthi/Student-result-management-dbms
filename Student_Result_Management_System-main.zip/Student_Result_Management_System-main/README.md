<h1 align="center">Resultaholic </h1>

## Overview

This project is focused on building an online portal of Student Result Management System directed to easier the management work of publishing results.

## :computer: Project Development:
  - Backend: PHP
  - Frontend: HTML, CSS, JS
  - DataBase: mySQL
 
## :computer: How to run this Project
  - Download and Unzip file on your local system copy 'rms' folder.
  - Put rms folder inside root directory-(C:\xampp\htdocs)

