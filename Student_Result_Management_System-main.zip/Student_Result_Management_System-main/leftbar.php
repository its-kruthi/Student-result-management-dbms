<!DOCTYPE html>
<html>

<head>
    <title>AdminPanel</title>
    <link rel="stylesheet" type="text/css" href="css/leftbar.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>
    <ul class="ul-verticle">
        <div class="li-verticle">
            <li><a onclick="hideNav()" href="enter-result.php">Enter Result</a></li>
            <li><a onclick="hideNav()" href="update-result.php">Update Result</a></li>
            <li><a onclick="hideNav()" href="view-result.php">View Details</a></li>
            <li><a onclick="hideNav()" href="delete-result.php">Delete Details</a></li>
            <li><a onclick="hideNav()" href="change-pass.php">Change Password</a></li>
            <img class="img" src="img/tech.png" style="margin-left: 0px;  height: 350px">
        </div>
    </ul>
</body>
</html>